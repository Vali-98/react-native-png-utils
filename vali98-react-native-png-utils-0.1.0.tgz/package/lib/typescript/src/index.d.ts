/**
 *
 * @param pngData base64 encoded PNG data
 * @returns contents of tEXt chunk
 */
export declare function extractPngTextChunk(pngData: string): string;
export declare function replacePngTextChunk(fileData: string, newData: string): string;
//# sourceMappingURL=index.d.ts.map
require "json"

package = JSON.parse(File.read(File.join(__dir__, "package.json")))

Pod::Spec.new do |s|
  s.name         = "PngUtils"
  s.version      = package["version"]
  s.summary      = package["description"]
  s.homepage     = package["homepage"]
  s.license      = package["license"]
  s.authors      = package["author"]

  s.platforms    = { :ios => min_ios_version_supported, :visionos => 1.0 }
  s.source       = { :git => "https://github.com/vali98/react-native-png-utils.git", :tag => "#{s.version}" }

  s.source_files = [
    # Implementation (Swift)
    "ios/**/*.{swift}",
    # Autolinking/Registration (Objective-C++)
    "ios/**/*.{m,mm}",
    # Implementation (C++ objects)
    "cpp/**/*.{hpp,cpp,c,h}",
  ]
  s.pod_target_xcconfig = {
    # O3 optimizations make stuff fast
    'OTHER_CPLUSPLUSFLAGS' => '$(inherited) -O3 -DPNGUTIL_ENABLE_NEON', 
    'OTHER_CFLAGS' => '$(inherited) -O3 -DPNGUTIL_ENABLE_NEON',
  }

  load 'nitrogen/generated/ios/PngUtils+autolinking.rb'
  add_nitrogen_files(s)

  s.dependency 'React-jsi'
  s.dependency 'React-callinvoker'
  install_modules_dependencies(s)
end
